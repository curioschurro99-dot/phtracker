import { i as defineEventHandler } from "../../_libs/h3+rou3+srvx.mjs";
//#region server/routes/api/health.ts
var health_default = defineEventHandler(() => ({ status: "ok" }));
//#endregion
export { health_default as default };
