import { i as defineEventHandler, l as readBody, r as createError } from "../../../_libs/h3+rou3+srvx.mjs";
import { a as habits, c as reminders, d as todos, f as users, i as groceries, l as sleepLogs, n as buys, o as logs, p as createSupabaseServerClient, r as cycleMeta, s as periods, t as db, u as thoughts } from "../../../_chunks/db.mjs";
import { n as eq } from "../../../_libs/drizzle-orm+postgres.mjs";
//#region server/routes/api/sync/save.ts
var save_default = defineEventHandler(async (event) => {
	const { data: { user }, error } = await createSupabaseServerClient(event).auth.getUser();
	if (error || !user) throw createError({
		statusCode: 401,
		statusMessage: "Unauthorized"
	});
	const uid = user.id;
	const body = await readBody(event);
	if (!body) throw createError({
		statusCode: 400,
		statusMessage: "Bad Request"
	});
	const state = body.state;
	await db.insert(users).values({ id: uid }).onConflictDoNothing();
	await db.transaction(async (tx) => {
		await tx.delete(habits).where(eq(habits.userId, uid));
		await tx.delete(logs).where(eq(logs.userId, uid));
		await tx.delete(todos).where(eq(todos.userId, uid));
		await tx.delete(buys).where(eq(buys.userId, uid));
		await tx.delete(groceries).where(eq(groceries.userId, uid));
		await tx.delete(periods).where(eq(periods.userId, uid));
		await tx.delete(cycleMeta).where(eq(cycleMeta.userId, uid));
		await tx.delete(reminders).where(eq(reminders.userId, uid));
		await tx.delete(thoughts).where(eq(thoughts.userId, uid));
		await tx.delete(sleepLogs).where(eq(sleepLogs.userId, uid));
		if (!tx) return;
		const h = state.habits;
		if (h.length) await tx.insert(habits).values(h.map((r) => ({
			...r,
			userId: uid
		})));
		const l = state.logs;
		if (l) {
			const rows = [];
			let id = 0;
			for (const [date, habitsMap] of Object.entries(l)) for (const [habitId, done] of Object.entries(habitsMap)) rows.push({
				id: `log-${uid}-${id++}`,
				userId: uid,
				date,
				habitId,
				done
			});
			if (rows.length) await tx.insert(logs).values(rows);
		}
		const t = state.todos;
		if (t.length) await tx.insert(todos).values(t.map((r) => ({
			...r,
			userId: uid
		})));
		const b = state.buys;
		if (b.length) await tx.insert(buys).values(b.map((r) => ({
			...r,
			userId: uid
		})));
		const g = state.groceries;
		if (g.length) await tx.insert(groceries).values(g.map((r) => ({
			...r,
			userId: uid
		})));
		const p = state.cycle?.periods;
		if (p.length) await tx.insert(periods).values(p.map((r) => ({
			id: `per-${uid}-${r.start}`,
			userId: uid,
			start: r.start,
			logged: r.logged
		})));
		const cm = state.cycle;
		if (cm && (cm.avgCycleLength || cm.avgPeriodLength)) await tx.insert(cycleMeta).values({
			userId: uid,
			avgCycleLength: cm.avgCycleLength ?? 28,
			avgPeriodLength: cm.avgPeriodLength ?? 5
		});
		const r = state.reminders;
		if (r.length) await tx.insert(reminders).values(r.map((ri) => ({
			...ri,
			userId: uid
		})));
		const th = state.thoughts;
		if (th.length) await tx.insert(thoughts).values(th.map((ri) => ({
			...ri,
			userId: uid,
			archived: ri.archived ?? false
		})));
		const sl = state.sleepLogs;
		if (sl) {
			const rows = Object.entries(sl).map(([date, v]) => ({
				id: `slp-${uid}-${date}`,
				userId: uid,
				date,
				bedtime: v.bedtime,
				wake: v.wake,
				quality: v.quality,
				note: v.note ?? null,
				updatedAt: v.updatedAt
			}));
			if (rows.length) await tx.insert(sleepLogs).values(rows);
		}
	});
	return { ok: true };
});
//#endregion
export { save_default as default };
