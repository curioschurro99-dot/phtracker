import { i as defineEventHandler, r as createError } from "../../../_libs/h3+rou3+srvx.mjs";
import { a as habits, c as reminders, d as todos, f as createSupabaseServerClient, i as groceries, l as sleepLogs, n as buys, o as logs, r as cycleMeta, s as periods, t as db, u as thoughts } from "../../../_chunks/db.mjs";
import { n as eq } from "../../../_libs/drizzle-orm+postgres.mjs";
//#region server/routes/api/sync/load.ts
var load_default = defineEventHandler(async (event) => {
	const { data: { user }, error } = await createSupabaseServerClient(event).auth.getUser();
	if (error || !user) throw createError({
		statusCode: 401,
		statusMessage: "Unauthorized"
	});
	const uid = user.id;
	const [h, l, t, b, g, p, cm, r, th, sl] = await Promise.all([
		db.select().from(habits).where(eq(habits.userId, uid)),
		db.select().from(logs).where(eq(logs.userId, uid)),
		db.select().from(todos).where(eq(todos.userId, uid)),
		db.select().from(buys).where(eq(buys.userId, uid)),
		db.select().from(groceries).where(eq(groceries.userId, uid)),
		db.select().from(periods).where(eq(periods.userId, uid)),
		db.select().from(cycleMeta).where(eq(cycleMeta.userId, uid)).then((r) => r[0] ?? null),
		db.select().from(reminders).where(eq(reminders.userId, uid)),
		db.select().from(thoughts).where(eq(thoughts.userId, uid)),
		db.select().from(sleepLogs).where(eq(sleepLogs.userId, uid))
	]);
	const logsMap = {};
	for (const row of l) {
		if (!logsMap[row.date]) logsMap[row.date] = {};
		logsMap[row.date][row.habitId] = row.done;
	}
	const sleepMap = {};
	for (const row of sl) sleepMap[row.date] = {
		bedtime: row.bedtime,
		wake: row.wake,
		quality: row.quality,
		note: row.note ?? void 0,
		updatedAt: row.updatedAt
	};
	return {
		habits: h.map((r) => ({
			id: r.id,
			name: r.name,
			description: r.description,
			order: r.order,
			activeDays: r.activeDays
		})),
		logs: logsMap,
		todos: t.map((r) => ({
			id: r.id,
			text: r.text,
			done: r.done,
			createdAt: r.createdAt,
			completedAt: r.completedAt
		})),
		buys: b.map((r) => ({
			id: r.id,
			text: r.text,
			price: r.price,
			done: r.done,
			createdAt: r.createdAt,
			completedAt: r.completedAt
		})),
		groceries: g.map((r) => ({
			id: r.id,
			text: r.text,
			price: r.price,
			done: r.done,
			createdAt: r.createdAt,
			completedAt: r.completedAt
		})),
		cycle: {
			periods: p.map((r) => ({
				start: r.start,
				logged: r.logged
			})),
			avgCycleLength: cm?.avgCycleLength ?? 28,
			avgPeriodLength: cm?.avgPeriodLength ?? 5
		},
		reminders: r.map((ri) => ({
			id: ri.id,
			habitId: ri.habitId,
			time: ri.time
		})),
		thoughts: th.map((t) => ({
			id: t.id,
			header: t.header,
			body: t.body,
			createdAt: t.createdAt,
			updatedAt: t.updatedAt,
			archived: t.archived
		})),
		sleepLogs: sleepMap
	};
});
//#endregion
export { load_default as default };
