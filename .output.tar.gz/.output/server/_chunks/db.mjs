import { n as __exportAll } from "../_runtime.mjs";
import { c as parseCookies, s as deleteCookie, u as setCookie } from "../_libs/h3+rou3+srvx.mjs";
import { t as createServerClient } from "../_libs/@supabase/ssr+[...].mjs";
import { a as integer, i as text, o as boolean, r as pgTable, s as src_default, t as drizzle } from "../_libs/drizzle-orm+postgres.mjs";
//#region src/lib/supabase-server.ts
function createSupabaseServerClient(event) {
	return createServerClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, { cookies: {
		getAll() {
			const cookies = parseCookies(event);
			return Object.entries(cookies).map(([name, value]) => ({
				name,
				value
			}));
		},
		setAll(cookies) {
			for (const { name, value, options } of cookies) if (value) if (options?.maxAge === 0) deleteCookie(event, name);
			else setCookie(event, name, value, options);
		}
	} });
}
//#endregion
//#region src/lib/db/schema.ts
var schema_exports = /* @__PURE__ */ __exportAll({
	buys: () => buys,
	cycleMeta: () => cycleMeta,
	groceries: () => groceries,
	habits: () => habits,
	logs: () => logs,
	periods: () => periods,
	reminders: () => reminders,
	sleepLogs: () => sleepLogs,
	thoughts: () => thoughts,
	todos: () => todos,
	users: () => users
});
var users = pgTable("users", { id: text("id").primaryKey() });
var habits = pgTable("habits", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	name: text("name").notNull(),
	description: text("description").notNull().default(""),
	order: integer("order").notNull().default(0),
	activeDays: text("active_days").array().notNull().default([])
});
var logs = pgTable("logs", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	date: text("date").notNull(),
	habitId: text("habit_id").notNull(),
	done: boolean("done").notNull().default(false)
});
var todos = pgTable("todos", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	text: text("text").notNull(),
	done: boolean("done").notNull().default(false),
	createdAt: text("created_at").notNull(),
	completedAt: text("completed_at")
});
var buys = pgTable("buys", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	text: text("text").notNull(),
	price: integer("price").notNull().default(0),
	done: boolean("done").notNull().default(false),
	createdAt: text("created_at").notNull(),
	completedAt: text("completed_at")
});
var groceries = pgTable("groceries", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	text: text("text").notNull(),
	price: integer("price").notNull().default(0),
	done: boolean("done").notNull().default(false),
	createdAt: text("created_at").notNull(),
	completedAt: text("completed_at")
});
var periods = pgTable("periods", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	start: text("start").notNull(),
	logged: boolean("logged").notNull().default(true)
});
var cycleMeta = pgTable("cycle_meta", {
	userId: text("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
	avgCycleLength: integer("avg_cycle_length").notNull().default(28),
	avgPeriodLength: integer("avg_period_length").notNull().default(5)
});
var reminders = pgTable("reminders", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	habitId: text("habit_id").notNull(),
	time: text("time").notNull()
});
var thoughts = pgTable("thoughts", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	header: text("header").notNull().default(""),
	body: text("body").notNull().default(""),
	createdAt: text("created_at").notNull(),
	updatedAt: text("updated_at").notNull(),
	archived: boolean("archived").notNull().default(false)
});
var sleepLogs = pgTable("sleep_logs", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
	date: text("date").notNull(),
	bedtime: text("bedtime").notNull(),
	wake: text("wake").notNull(),
	quality: text("quality").notNull(),
	note: text("note"),
	updatedAt: text("updated_at").notNull()
});
var db = drizzle(src_default(process.env.DATABASE_URL), { schema: schema_exports });
//#endregion
export { habits as a, reminders as c, todos as d, createSupabaseServerClient as f, groceries as i, sleepLogs as l, buys as n, logs as o, cycleMeta as r, periods as s, db as t, thoughts as u };
