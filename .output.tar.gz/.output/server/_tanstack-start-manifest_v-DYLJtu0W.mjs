//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DYLJtu0W.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/signup"
		],
		preloads: ["/assets/index-hj_AjLtQ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-hj_AjLtQ.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CMlkaHxg.js", "/assets/ui-Cxcjjodp.js"]
	},
	"/login": {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-wpOa2k5e.js", "/assets/ui-Cxcjjodp.js"]
	},
	"/signup": {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/signup.tsx",
		children: void 0,
		preloads: ["/assets/signup-imdVCwYZ.js", "/assets/ui-Cxcjjodp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
