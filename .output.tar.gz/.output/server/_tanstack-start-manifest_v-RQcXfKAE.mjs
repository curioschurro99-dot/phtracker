//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-RQcXfKAE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/signup"
		],
		preloads: ["/assets/index-ChyN7x5F.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ChyN7x5F.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CXuGSI38.js", "/assets/ui-BDovNruv.js"]
	},
	"/login": {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DpP2a4Pv.js", "/assets/ui-BDovNruv.js"]
	},
	"/signup": {
		filePath: "C:/Users/ellis/OneDrive/Documents/GitHub/phtracker/src/routes/signup.tsx",
		children: void 0,
		preloads: ["/assets/signup-Dh-p6QFo.js", "/assets/ui-BDovNruv.js"]
	}
} });
//#endregion
export { tsrStartManifest };
