import { n as createBrowserClient } from "../_libs/@supabase/ssr+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-browser-CvODyaqC.js
var supabase = createBrowserClient(void 0, void 0);
//#endregion
export { supabase as t };
