import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./supabase-browser-BQLg2638.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as COLORS, r as Card, t as Button, u as Input } from "./ui-BmBluzMB.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signup-D_4STvZD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SignupPage() {
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const handleSubmit = async (e) => {
		e.preventDefault();
		setError("");
		if (password !== confirmPassword) {
			setError("Passwords do not match");
			return;
		}
		if (password.length < 6) {
			setError("Password must be at least 6 characters");
			return;
		}
		const { error: err } = await supabase.auth.signUp({
			email,
			password,
			options: { data: { name } }
		});
		if (err) {
			setError(err.message ?? "Sign up failed");
			return;
		}
		navigate({ to: "/" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			minHeight: "100vh",
			display: "flex",
			alignItems: "center",
			justifyContent: "center",
			background: COLORS.bg,
			padding: 20
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			style: {
				width: "100%",
				maxWidth: 400
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					style: {
						fontSize: 24,
						fontWeight: 700,
						marginBottom: 4
					},
					children: "Create account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: {
						fontSize: 14,
						color: COLORS.sub,
						marginBottom: 20
					},
					children: "Start tracking your habits"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					style: {
						display: "grid",
						gap: 12
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							style: {
								fontSize: 13,
								fontWeight: 600,
								display: "block",
								marginBottom: 4
							},
							children: "Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Your name",
							required: true,
							style: { width: "100%" }
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							style: {
								fontSize: 13,
								fontWeight: 600,
								display: "block",
								marginBottom: 4
							},
							children: "Email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							placeholder: "your@email.com",
							required: true,
							style: { width: "100%" }
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							style: {
								fontSize: 13,
								fontWeight: 600,
								display: "block",
								marginBottom: 4
							},
							children: "Password"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							value: password,
							onChange: (e) => setPassword(e.target.value),
							placeholder: "At least 6 characters",
							required: true,
							style: { width: "100%" }
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							style: {
								fontSize: 13,
								fontWeight: 600,
								display: "block",
								marginBottom: 4
							},
							children: "Confirm password"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							value: confirmPassword,
							onChange: (e) => setConfirmPassword(e.target.value),
							placeholder: "Repeat password",
							required: true,
							style: { width: "100%" }
						})] }),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							style: {
								fontSize: 13,
								color: "#C53030"
							},
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							style: { width: "100%" },
							children: "Create account"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					style: {
						fontSize: 13,
						color: COLORS.sub,
						marginTop: 16,
						textAlign: "center"
					},
					children: [
						"Already have an account?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							style: {
								color: COLORS.blue,
								textDecoration: "none",
								fontWeight: 600
							},
							children: "Sign in"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { SignupPage as component };
