import { n as createBrowserClient } from "../_libs/@supabase/ssr+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-browser-BQLg2638.js
var supabase = createBrowserClient("https://pqvheypxqjufdspkvzpk.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBxdmhleXB4cWp1ZmRzcGt2enBrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM0OTYwMTcsImV4cCI6MjA5OTA3MjAxN30.nhIhwi1mwZkSE7pIY-r_AseTDwtnclUyi9-bur1bqGM");
//#endregion
export { supabase as t };
