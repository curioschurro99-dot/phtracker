import { i as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as IconArrowDown, c as IconPencil, d as Muted, f as SectionTitle, i as IconArchive, l as IconTrash, n as COLORS, o as IconArrowUp, p as Textarea, r as Card, s as IconCheck, t as Button, u as Input } from "./ui-BmBluzMB.mjs";
import { g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useAuth } from "./auth-context-DdlRkNyo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B2U5AStY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DAYS = [
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat",
	"Sun"
];
var WEEKDAYS = [
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri"
];
var WEEKENDS = ["Sat", "Sun"];
var ALL_DAYS = [...DAYS];
function todayStr(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function dayNameFromDate(d) {
	return DAYS[(d.getDay() + 6) % 7];
}
function uid() {
	return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
var weekdayList = [
	["8:00 – 8:20 AM | Wake + Hydrate (Bottled water + salt or lemon)", "Open the windows, let some light in — helps reset your body clock."],
	["8:20 – 10:00 AM | Breakfast + Daily To Do + News", "Protein-forward (eggs, yogurt, tofu). Sit down to eat — no phone."],
	["10:00 – 10:45 AM | Shower + Get Dressed Properly + Laundry", "A small psychological trick to kick start your day."],
	["10:45 – 11:45 AM | Finance News", "Daily read — markets, portfolio check-ins. Low-stress, engaged-brain activity."],
	["11:45 AM – 12:40 PM | Productive Block", "Job hunting/applications, a course, the counselling program research, or admin/errands."],
	["12:45 – 2:00 PM | Water + Light Walk + Prep Lunch", "Walk outside (for sunlight, fresh air)."],
	["2:00 – 3:00 PM | Cook + Eat Lunch", "Main meal of the day. ~30 mins to cook."],
	["3:00 – 5:00 PM | Rest / Drama Time / Reading", "Guilt-free. This is a genuine leisure block."],
	["5:00 – 5:45 PM | Second Movement Block", "A brisk walk, a second shorter yoga session, or light strength training (bodyweight squats, resistance bands)."],
	["6:00 – 8:30 PM | Cook + Eat Dinner + Water", "Finish eating by 7:30pm–8:30pm so digestion has time before bed."],
	["8:30 – 9:00 PM | Evening Leisure", "Last big glass of water for the evening & unwind."],
	["9:00 – 9:30 PM | Gentle Evening Yoga / Stretch", "Restorative poses — signal to body it's time to slow down."],
	["9:30 – 10:30 PM | Wind Down", "Skincare, tidy up, prep clothes/food for tmr. Avoid heavy phone scrolling here if you can."],
	["10:30 – 11:00 PM | Bible + Prayer + Sleep", "Consistent bedtime is critical — poor sleep disrupts hunger hormones."]
];
var satList = [
	["7:30 – 7:40 AM | Wake + Hydrate (A glass of water + salt or lemon)", "Boil eggs (7 mins)."],
	["7:40 – 8:00 AM | Shower + Get Dressed Properly", "A small psychological trick to kick start your day."],
	["8:00 – 8:20 AM | Breakfast", "Protein-forward (eggs, yogurt, tofu)."],
	["8:20 – 8:55 AM | Commute to Tzu Tzih", "Plan your tuition program."],
	["9:00 – 11:15 AM | Tuition", "Tuition."],
	["11:15 AM – 1:30 PM | Water + Northpoint City Library + Lunch", "Read, shop, lunch and grocery."],
	["1:30 – 2:30 PM | Saturday Date with Bf", "Walk outside (for sunlight, fresh air, and breaking up sitting)."],
	["2:30 – 9:00 PM | Free Play + Water", "Free playyyyy."],
	["9:00 – 9:30 PM | Gentle Evening Yoga / Stretch", "Restorative poses — signal to body it's time to slow down."],
	["9:30 – 10:30 PM | Wind Down", "Skincare, tidy up, prep clothes/food for tmr. Avoid heavy phone scrolling here if you can."],
	["10:30 – 11:00 PM | Bible + Prayer + Sleep", "Consistent bedtime is critical — poor sleep disrupts hunger hormones."]
];
var sunList = [
	["8:00 – 8:10 AM | Wake + Hydrate (A glass of water + salt or lemon)", "Open the windows, let some light in — helps reset your body clock."],
	["8:10 – 8:15 AM | Shower + Get Dressed Properly", "A small psychological trick to kick start your day."],
	["8:15 – 9:30 AM | Breakfast", "Protein-forward (eggs, yogurt, tofu). Drama."],
	["9:30 AM – 12:00 PM | Church?", "Depends. Chill."],
	["12:00 – 4:30 PM | Play Time", "Free play."],
	["4:30 – 9:00 PM | Sunday Date with Bf", "Walk outside (for sunlight & fresh air)."],
	["9:00 – 9:30 PM | Gentle Evening Yoga / Stretch", "Restorative poses — signal to body it's time to slow down."],
	["9:30 – 10:30 PM | Wind Down", "Skincare, tidy up, prep clothes/food for tmr. Avoid heavy phone scrolling here if you can."],
	["10:30 – 11:00 PM | Bible + Prayer + Sleep", "Consistent bedtime is critical — poor sleep disrupts hunger hormones."]
];
var dailyList = [
	["Total Water Intake 1.5 Litre", ""],
	["Total Step Count >10,000", ""],
	["135 Coffee, Else Decaf.", "Too much coffee - stomach issues."]
];
function seedHabits() {
	let order = 0;
	const mk = (list, active) => list.map(([name, description]) => ({
		id: uid(),
		name,
		description,
		order: order++,
		activeDays: active
	}));
	return [
		...mk(dailyList, ALL_DAYS),
		...mk(weekdayList, WEEKDAYS),
		...mk(satList, ["Sat"]),
		...mk(sunList, ["Sun"])
	];
}
var PHASE_COLORS = {
	menses: {
		bg: "#FADAE1",
		text: "#8A2E45",
		letter: "M",
		label: "Menses"
	},
	follicular: {
		bg: "#D6F0DA",
		text: "#256B3A",
		letter: "F",
		label: "Follicular"
	},
	fertile: {
		bg: "#FCE7C2",
		text: "#8A5A1A",
		letter: "F",
		label: "Fertile"
	},
	luteal: {
		bg: "#E3D6F0",
		text: "#5A3A8A",
		letter: "L",
		label: "Luteal"
	}
};
function daysBetween(a, b) {
	const da = /* @__PURE__ */ new Date(a + "T00:00:00");
	const db = /* @__PURE__ */ new Date(b + "T00:00:00");
	return Math.round((db.getTime() - da.getTime()) / 864e5);
}
function cycleInfoForDate(cycle, dateStr) {
	if (!cycle.periods.length) return null;
	const sorted = [...cycle.periods].sort((a, b) => a.start.localeCompare(b.start));
	let ref = sorted[0];
	for (const p of sorted) if (p.start <= dateStr) ref = p;
	else break;
	const diff = daysBetween(ref.start, dateStr);
	const cycleLen = cycle.avgCycleLength || 28;
	let day = diff;
	let estimated = false;
	if (day < 0) {
		day = (day % cycleLen + cycleLen) % cycleLen;
		estimated = true;
	} else if (day >= cycleLen) {
		day = day % cycleLen;
		estimated = true;
	}
	const periodLen = cycle.avgPeriodLength || 5;
	const ovulation = cycleLen - 14;
	const fertileStart = cycleLen - 16;
	const fertileEnd = cycleLen - 12;
	let phase;
	if (day < periodLen) phase = "menses";
	else if (day >= fertileStart && day < fertileEnd) phase = "fertile";
	else if (day < ovulation) phase = "follicular";
	else phase = "luteal";
	return {
		day: day + 1,
		phase,
		estimated
	};
}
function storageKey(userId) {
	if (userId) return `habit-tracker-state-v2-${userId}`;
	return "habit-tracker-state-v2";
}
function initialState() {
	return {
		habits: seedHabits(),
		logs: {},
		todos: [],
		buys: [],
		cycle: {
			periods: [],
			avgCycleLength: 28,
			avgPeriodLength: 5
		},
		reminders: [],
		seeded: true,
		thoughts: [],
		sleepLogs: {},
		groceries: []
	};
}
function load(userId) {
	if (typeof window === "undefined") return initialState();
	try {
		const raw = window.localStorage.getItem(storageKey(userId));
		if (!raw) return initialState();
		const parsed = JSON.parse(raw);
		return {
			...initialState(),
			...parsed
		};
	} catch {
		return initialState();
	}
}
function useHabitStore(userId, syncClient) {
	const [state, setState] = (0, import_react.useState)(() => typeof window === "undefined" ? {
		habits: [],
		logs: {},
		todos: [],
		buys: [],
		cycle: {
			periods: [],
			avgCycleLength: 28,
			avgPeriodLength: 5
		},
		reminders: [],
		seeded: false,
		thoughts: [],
		sleepLogs: {},
		groceries: []
	} : load(userId));
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const syncTimer = (0, import_react.useRef)();
	(0, import_react.useEffect)(() => {
		setState(load(userId));
		setHydrated(true);
	}, [userId]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		try {
			window.localStorage.setItem(storageKey(userId), JSON.stringify(state));
		} catch {}
	}, [
		state,
		hydrated,
		userId
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated || !syncClient) return;
		syncClient.load().then((serverState) => {
			if (!serverState || !syncClient) return;
			if (!(serverState.habits.length > 0 || Object.keys(serverState.logs).length > 0 || serverState.todos.length > 0)) return;
			setState((prev) => ({
				...initialState(),
				...prev,
				...serverState
			}));
		});
	}, [hydrated, syncClient]);
	(0, import_react.useEffect)(() => {
		if (!hydrated || !syncClient) return;
		if (syncTimer.current) clearTimeout(syncTimer.current);
		syncTimer.current = setTimeout(() => {
			syncClient.save(state);
		}, 2e3);
		return () => {
			if (syncTimer.current) clearTimeout(syncTimer.current);
		};
	}, [
		state,
		hydrated,
		syncClient
	]);
	return {
		state,
		setState,
		update: (0, import_react.useCallback)((fn) => setState((prev) => fn(prev)), []),
		hydrated
	};
}
function createSyncClient(userId) {
	const base = "/api/sync";
	async function load() {
		try {
			const res = await fetch(`${base}/load`, { credentials: "include" });
			if (!res.ok) return null;
			return await res.json();
		} catch {
			return null;
		}
	}
	async function save(state) {
		try {
			return (await fetch(`${base}/save`, {
				method: "POST",
				credentials: "include",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ state })
			})).ok;
		} catch {
			return false;
		}
	}
	return {
		load,
		save,
		userId
	};
}
function DaysSelector({ value, onChange }) {
	const toggle = (d) => {
		onChange(value.includes(d) ? value.filter((x) => x !== d) : [...value, d]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			gap: 6,
			flexWrap: "wrap",
			marginBottom: 8
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetBtn, {
				label: "Every day",
				onClick: () => onChange(ALL_DAYS)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetBtn, {
				label: "Weekdays",
				onClick: () => onChange(WEEKDAYS)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetBtn, {
				label: "Weekends",
				onClick: () => onChange(WEEKENDS)
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			display: "flex",
			gap: 6,
			flexWrap: "wrap"
		},
		children: DAYS.map((d) => {
			const on = value.includes(d);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => toggle(d),
				style: {
					border: `1px solid ${on ? COLORS.text : COLORS.border}`,
					background: on ? COLORS.text : "#fff",
					color: on ? "#fff" : COLORS.sub,
					borderRadius: 999,
					padding: "6px 12px",
					fontSize: 13,
					fontWeight: 500,
					cursor: "pointer"
				},
				children: d
			}, d);
		})
	})] });
}
function PresetBtn({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		style: {
			border: `1px solid ${COLORS.border}`,
			background: "#fff",
			color: COLORS.text,
			borderRadius: 999,
			padding: "5px 12px",
			fontSize: 12,
			cursor: "pointer"
		},
		children: label
	});
}
var TABS = [
	{
		id: "today",
		label: "Today"
	},
	{
		id: "week",
		label: "Week"
	},
	{
		id: "month",
		label: "Month"
	},
	{
		id: "cycle",
		label: "Cycle"
	},
	{
		id: "todos",
		label: "To-Dos"
	},
	{
		id: "buys",
		label: "To-Buys"
	},
	{
		id: "grocery",
		label: "Grocery"
	},
	{
		id: "thoughts",
		label: "Thoughts"
	},
	{
		id: "thot-archive",
		label: "Thot-Archive"
	},
	{
		id: "analysis",
		label: "Analysis"
	},
	{
		id: "habits",
		label: "Habits"
	},
	{
		id: "reminders",
		label: "Reminders"
	}
];
function HabitApp() {
	const [tab, setTab] = (0, import_react.useState)("today");
	const { userId } = useAuth();
	const store = useHabitStore(userId, userId ? createSyncClient(userId) : null);
	useReminderNotifier(store);
	if (!store.hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
		minHeight: "100vh",
		background: COLORS.bg
	} });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			minHeight: "100vh",
			background: COLORS.bg,
			color: COLORS.text,
			fontFamily: "-apple-system, BlinkMacSystemFont, \"SF Pro Display\", \"SF Pro Text\", \"Helvetica Neue\", Arial, sans-serif"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				maxWidth: 1100,
				margin: "0 auto",
				padding: "24px 16px 80px"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					style: {
						display: "flex",
						alignItems: "center",
						justifyContent: "space-between",
						marginBottom: 20,
						flexWrap: "wrap",
						gap: 12
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							fontSize: 20,
							fontWeight: 700,
							letterSpacing: -.2
						},
						children: "Habit Tracker"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					style: {
						background: "#EDEDF0",
						borderRadius: 999,
						padding: 4,
						display: "flex",
						gap: 2,
						overflowX: "auto",
						marginBottom: 20
					},
					children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(t.id),
						style: {
							background: tab === t.id ? COLORS.text : "transparent",
							color: tab === t.id ? "#fff" : COLORS.sub,
							border: "none",
							borderRadius: 999,
							padding: "8px 14px",
							fontSize: 13,
							fontWeight: 500,
							cursor: "pointer",
							whiteSpace: "nowrap"
						},
						children: t.label
					}, t.id))
				}),
				tab === "today" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayTab, { store }),
				tab === "week" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekTab, { store }),
				tab === "month" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthTab, { store }),
				tab === "cycle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CycleTab, { store }),
				tab === "todos" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodosTab, { store }),
				tab === "buys" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuysTab, { store }),
				tab === "grocery" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroceryTab, { store }),
				tab === "thoughts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThoughtsTab, {
					store,
					onNavigate: setTab
				}),
				tab === "thot-archive" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThotArchiveTab, { store }),
				tab === "analysis" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalysisTab, { store }),
				tab === "habits" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitsTab, { store }),
				tab === "reminders" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemindersTab, { store })
			]
		})
	});
}
function formatTs(ts) {
	if (!ts) return "";
	const d = new Date(ts);
	if (isNaN(d.getTime())) return ts;
	const parts = new Intl.DateTimeFormat("en-GB", {
		timeZone: "Asia/Singapore",
		day: "2-digit",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	}).formatToParts(d);
	const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
	return `${get("day")}/${get("month")}/${get("year")} ${get("hour")}:${get("minute")}`;
}
function TodayTab({ store }) {
	const now = /* @__PURE__ */ new Date();
	const today = todayStr(now);
	const dayName = dayNameFromDate(now);
	const scheduled = store.state.habits.filter((h) => h.activeDays.includes(dayName)).sort((a, b) => a.order - b.order);
	const log = store.state.logs[today] || {};
	const done = scheduled.filter((h) => log[h.id]).length;
	const pct = scheduled.length ? Math.round(done / scheduled.length * 100) : 0;
	const cycleInfo = cycleInfoForDate(store.state.cycle, today);
	const toggle = (id) => {
		store.update((s) => {
			const dayLog = { ...s.logs[today] || {} };
			dayLog[id] = !dayLog[id];
			return {
				...s,
				logs: {
					...s.logs,
					[today]: dayLog
				}
			};
		});
	};
	const longDate = now.toLocaleDateString("en-US", {
		weekday: "long",
		month: "long",
		day: "numeric"
	});
	const todosPreview = store.state.todos.filter((t) => !t.done).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					style: {
						fontSize: 26,
						fontWeight: 700,
						margin: 0
					},
					children: longDate
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
					style: { fontSize: 14 },
					children: [
						done,
						" of ",
						scheduled.length,
						" habits complete"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						marginTop: 16,
						display: "flex",
						justifyContent: "space-between",
						fontSize: 13,
						fontWeight: 500
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Daily Progress" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [pct, "%"] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						height: 6,
						background: "#EDEDF0",
						borderRadius: 999,
						marginTop: 6,
						overflow: "hidden"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
						width: `${pct}%`,
						height: "100%",
						background: COLORS.green,
						transition: "width 200ms"
					} })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						marginTop: 20,
						display: "grid",
						gap: 8
					},
					children: [scheduled.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No habits scheduled today." }), scheduled.map((h) => {
						const isDone = !!log[h.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								gap: 12,
								alignItems: "flex-start",
								padding: "8px 4px"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => toggle(h.id),
								"aria-label": isDone ? "Mark incomplete" : "Mark complete",
								style: {
									width: 26,
									height: 26,
									borderRadius: 999,
									border: `1.5px solid ${isDone ? COLORS.green : COLORS.border}`,
									background: isDone ? COLORS.green : "#fff",
									cursor: "pointer",
									display: "flex",
									alignItems: "center",
									justifyContent: "center",
									flexShrink: 0,
									marginTop: 2
								},
								children: isDone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconCheck, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									minWidth: 0,
									flex: 1
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									style: {
										fontSize: 14,
										fontWeight: 500,
										color: isDone ? COLORS.sub : COLORS.text,
										textDecoration: isDone ? "line-through" : "none"
									},
									children: h.name
								}), h.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
									style: { fontSize: 12 },
									children: h.description
								})]
							})]
						}, h.id);
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					justifyContent: "space-between",
					gap: 12,
					flexWrap: "wrap"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						fontSize: 14,
						fontWeight: 600
					},
					children: cycleInfo ? `Cycle Day ${cycleInfo.day}` : "Cycle not set"
				}), cycleInfo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhasePill, {
					phase: cycleInfo.phase,
					estimated: cycleInfo.estimated
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Today's To-Dos" }),
				todosPreview.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Nothing pending." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						display: "grid",
						gap: 6
					},
					children: todosPreview.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { fontSize: 14 },
						children: ["• ", t.text]
					}, t.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepLogCard, {
				store,
				dateStr: today
			})
		]
	});
}
function SleepLogCard({ store, dateStr }) {
	const existing = store.state.sleepLogs[dateStr];
	const [bedtime, setBedtime] = (0, import_react.useState)(existing?.bedtime || "");
	const [wake, setWake] = (0, import_react.useState)(existing?.wake || "");
	const [quality, setQuality] = (0, import_react.useState)(existing?.quality || "");
	const [note, setNote] = (0, import_react.useState)(existing?.note || "");
	const [saved, setSaved] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setBedtime(existing?.bedtime || "");
		setWake(existing?.wake || "");
		setQuality(existing?.quality || "");
		setNote(existing?.note || "");
	}, [
		dateStr,
		existing?.bedtime,
		existing?.wake,
		existing?.quality,
		existing?.note
	]);
	const save = () => {
		store.update((s) => ({
			...s,
			sleepLogs: {
				...s.sleepLogs,
				[dateStr]: {
					bedtime,
					wake,
					quality,
					note,
					updatedAt: (/* @__PURE__ */ new Date()).toISOString()
				}
			}
		}));
		setSaved(true);
		window.setTimeout(() => setSaved(false), 1500);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Sleep Log" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
			style: { fontSize: 12 },
			children: "Log last night's sleep and how you feel this morning."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "grid",
				gridTemplateColumns: "1fr 1fr",
				gap: 12,
				marginTop: 12
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				style: {
					display: "grid",
					gap: 6,
					fontSize: 13
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Bedtime (last night)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "time",
					value: bedtime,
					onChange: (e) => setBedtime(e.target.value)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				style: {
					display: "grid",
					gap: 6,
					fontSize: 13
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Wake time (this morning)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "time",
					value: wake,
					onChange: (e) => setWake(e.target.value)
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			style: {
				display: "grid",
				gap: 6,
				fontSize: 13,
				marginTop: 12
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Sleep quality" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: quality,
				onChange: (e) => setQuality(e.target.value),
				placeholder: "How well did you sleep? Dreams, wake-ups, energy on waking..."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			style: {
				display: "grid",
				gap: 6,
				fontSize: 13,
				marginTop: 12
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Note for the day" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: note,
				onChange: (e) => setNote(e.target.value),
				placeholder: "How was today? e.g. Sick, Unwell, Energetic..."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				alignItems: "center",
				gap: 10,
				marginTop: 12
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: save,
					children: "Save"
				}),
				saved && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
					style: {
						fontSize: 12,
						color: COLORS.green
					},
					children: "Saved"
				}),
				existing?.updatedAt && !saved && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
					style: { fontSize: 12 },
					children: ["Last updated ", formatTs(existing.updatedAt)]
				})
			]
		})
	] });
}
function ThoughtsTab({ store, onNavigate }) {
	const [header, setHeader] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [editHeader, setEditHeader] = (0, import_react.useState)("");
	const [editBody, setEditBody] = (0, import_react.useState)("");
	const [viewingId, setViewingId] = (0, import_react.useState)(null);
	const add = () => {
		if (!header.trim() && !body.trim()) return;
		const now = (/* @__PURE__ */ new Date()).toISOString();
		store.update((s) => ({
			...s,
			thoughts: [{
				id: uid(),
				header: header.trim(),
				body: body.trim(),
				archived: false,
				createdAt: now,
				updatedAt: now
			}, ...s.thoughts]
		}));
		setHeader("");
		setBody("");
	};
	const startEdit = (id, h, b) => {
		setEditingId(id);
		setEditHeader(h);
		setEditBody(b);
	};
	const saveEdit = () => {
		const now = (/* @__PURE__ */ new Date()).toISOString();
		store.update((s) => ({
			...s,
			thoughts: s.thoughts.map((t) => t.id === editingId ? {
				...t,
				header: editHeader,
				body: editBody,
				updatedAt: now
			} : t)
		}));
		setEditingId(null);
	};
	const del = (id) => {
		store.update((s) => ({
			...s,
			thoughts: s.thoughts.filter((t) => t.id !== id)
		}));
		if (viewingId === id) setViewingId(null);
	};
	const archive = (id) => store.update((s) => ({
		...s,
		thoughts: s.thoughts.map((t) => t.id === id ? {
			...t,
			archived: true,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : t)
	}));
	const unarchive = (id) => {
		store.update((s) => ({
			...s,
			thoughts: s.thoughts.map((t) => t.id === id ? {
				...t,
				archived: false,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			} : t)
		}));
		setViewingId(null);
	};
	const activeThoughts = store.state.thoughts.filter((t) => !t.archived).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
	const archivedLast5 = store.state.thoughts.filter((t) => t.archived).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);
	const viewingThought = viewingId ? store.state.thoughts.find((t) => t.id === viewingId) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gridTemplateColumns: "1fr 240px",
			gap: 16,
			alignItems: "start"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "grid",
				gap: 16
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "New Thought" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gap: 10
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Header (optional)",
						value: header,
						onChange: (e) => setHeader(e.target.value),
						style: {
							fontWeight: 700,
							fontSize: 15
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						placeholder: "Write your thought...",
						value: body,
						onChange: (e) => setBody(e.target.value),
						style: { minHeight: 100 }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: add,
						children: "Add note"
					}) })
				]
			})] }), viewingThought ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					alignItems: "center",
					marginBottom: 12
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Archived Note" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setViewingId(null),
					children: "Close"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				viewingThought.header && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						fontSize: 16,
						fontWeight: 700,
						marginBottom: 4
					},
					children: viewingThought.header
				}),
				viewingThought.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						fontSize: 14,
						whiteSpace: "pre-wrap",
						lineHeight: 1.5,
						marginBottom: 8
					},
					children: viewingThought.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
					style: {
						fontSize: 11,
						display: "block",
						marginBottom: 10
					},
					children: [formatTs(viewingThought.createdAt), viewingThought.updatedAt && viewingThought.updatedAt !== viewingThought.createdAt && ` · edited ${formatTs(viewingThought.updatedAt)}`]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						gap: 8
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => unarchive(viewingThought.id),
						children: "Unarchive"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => del(viewingThought.id),
						children: "Delete"
					})]
				})
			] })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, { children: [
					"Notes (",
					activeThoughts.length,
					")"
				] }),
				activeThoughts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No thoughts yet." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						display: "grid",
						gap: 12
					},
					children: activeThoughts.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							padding: "10px 0",
							borderBottom: `1px solid ${COLORS.border}`
						},
						children: editingId === t.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "grid",
								gap: 8
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: editHeader,
									onChange: (e) => setEditHeader(e.target.value),
									placeholder: "Header (optional)",
									style: {
										fontWeight: 700,
										fontSize: 15
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: editBody,
									onChange: (e) => setEditBody(e.target.value),
									style: { minHeight: 100 }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										display: "flex",
										gap: 8
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: saveEdit,
										children: "Save"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "secondary",
										onClick: () => setEditingId(null),
										children: "Cancel"
									})]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								gap: 10,
								alignItems: "flex-start"
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										flex: 1,
										minWidth: 0
									},
									children: [
										t.header && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											style: {
												fontSize: 16,
												fontWeight: 700,
												marginBottom: 4
											},
											children: t.header
										}),
										t.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											style: {
												fontSize: 14,
												whiteSpace: "pre-wrap",
												lineHeight: 1.5
											},
											children: t.body
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
											style: {
												fontSize: 11,
												display: "block",
												marginTop: 6
											},
											children: [formatTs(t.createdAt), t.updatedAt && t.updatedAt !== t.createdAt && ` · edited ${formatTs(t.updatedAt)}`]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: () => startEdit(t.id, t.header, t.body),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconPencil, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: () => archive(t.id),
									title: "Archive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArchive, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: () => del(t.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
								})
							]
						})
					}, t.id))
				})
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				display: "grid",
				gap: 16
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Archive" }),
				archivedLast5.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No archived notes." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						display: "grid",
						gap: 8
					},
					children: archivedLast5.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setViewingId(t.id),
						title: t.body ? t.body.slice(0, 150) : "",
						style: {
							display: "block",
							width: "100%",
							textAlign: "left",
							background: viewingId === t.id ? COLORS.active : "none",
							border: "none",
							borderRadius: 6,
							padding: "6px 8px",
							cursor: "pointer",
							fontSize: 13,
							color: COLORS.text,
							lineHeight: 1.3
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontWeight: 600,
								overflow: "hidden",
								textOverflow: "ellipsis",
								whiteSpace: "nowrap"
							},
							children: t.header || "(no header)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
							style: { fontSize: 11 },
							children: formatTs(t.createdAt)
						})]
					}, t.id))
				}),
				store.state.thoughts.filter((t) => t.archived).length > 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: { marginTop: 8 },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => onNavigate?.("thot-archive"),
						children: "View all in Thot-Archive →"
					})
				})
			] })
		})]
	});
}
function ThotArchiveTab({ store }) {
	const [expandedId, setExpandedId] = (0, import_react.useState)(null);
	const del = (id) => store.update((s) => ({
		...s,
		thoughts: s.thoughts.filter((t) => t.id !== id)
	}));
	const unarchive = (id) => store.update((s) => ({
		...s,
		thoughts: s.thoughts.map((t) => t.id === id ? {
			...t,
			archived: false,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : t)
	}));
	const archived = store.state.thoughts.filter((t) => t.archived).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, { children: [
				"Thot-Archive (",
				archived.length,
				")"
			] }),
			archived.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No archived notes." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "grid",
					gap: 4
				},
				children: archived.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: { borderBottom: `1px solid ${COLORS.border}` },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setExpandedId(expandedId === t.id ? null : t.id),
						title: t.body ? t.body.slice(0, 150) : "",
						style: {
							display: "flex",
							alignItems: "center",
							gap: 8,
							width: "100%",
							textAlign: "left",
							background: "none",
							border: "none",
							padding: "10px 8px",
							cursor: "pointer",
							fontSize: 14,
							color: COLORS.text,
							fontFamily: "inherit"
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: {
									fontSize: 12,
									color: COLORS.sub,
									width: 16,
									flexShrink: 0
								},
								children: expandedId === t.id ? "▼" : "▶"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: {
									flex: 1,
									fontWeight: 600,
									overflow: "hidden",
									textOverflow: "ellipsis",
									whiteSpace: "nowrap"
								},
								children: t.header || "(no header)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
								style: {
									fontSize: 12,
									flexShrink: 0
								},
								children: formatTs(t.createdAt)
							})
						]
					}), expandedId === t.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { padding: "0 8px 12px 32px" },
						children: [
							t.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: {
									fontSize: 14,
									whiteSpace: "pre-wrap",
									lineHeight: 1.5,
									marginBottom: 8
								},
								children: t.body
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
								style: {
									fontSize: 11,
									display: "block",
									marginBottom: 10
								},
								children: [formatTs(t.createdAt), t.updatedAt && t.updatedAt !== t.createdAt && ` · edited ${formatTs(t.updatedAt)}`]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									gap: 8
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => unarchive(t.id),
									children: "Unarchive"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: () => del(t.id),
									children: "Delete"
								})]
							})
						]
					})]
				}, t.id))
			})
		] })
	});
}
function PhasePill({ phase, estimated }) {
	const c = PHASE_COLORS[phase];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		style: {
			background: c.bg,
			color: c.text,
			padding: "4px 12px",
			borderRadius: 999,
			fontSize: 12,
			fontWeight: 600
		},
		children: [c.label, estimated ? " · estimated" : " · logged"]
	});
}
function WeekTab({ store }) {
	const [anchor, setAnchor] = (0, import_react.useState)(() => startOfWeek(/* @__PURE__ */ new Date()));
	const days = Array.from({ length: 7 }, (_, i) => {
		const d = new Date(anchor);
		d.setDate(anchor.getDate() + i);
		return d;
	});
	const habits = [...store.state.habits].sort((a, b) => a.order - b.order);
	const today = todayStr();
	const toggle = (habitId, date) => {
		store.update((s) => {
			const dayLog = { ...s.logs[date] || {} };
			dayLog[habitId] = !dayLog[habitId];
			return {
				...s,
				logs: {
					...s.logs,
					[date]: dayLog
				}
			};
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			justifyContent: "space-between",
			alignItems: "center",
			marginBottom: 16
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => setAnchor(addDays(anchor, -7)),
				children: "← Prev"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { fontWeight: 600 },
				children: [
					days[0].toLocaleDateString("en-US", {
						month: "short",
						day: "numeric"
					}),
					" –",
					" ",
					days[6].toLocaleDateString("en-US", {
						month: "short",
						day: "numeric",
						year: "numeric"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => setAnchor(addDays(anchor, 7)),
				children: "Next →"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: { overflowX: "auto" },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			style: {
				width: "100%",
				borderCollapse: "separate",
				borderSpacing: 0,
				tableLayout: "fixed",
				minWidth: 640
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("colgroup", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "32%" } }), days.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: `${68 / 7}%` } }, i))] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					style: {
						textAlign: "left",
						fontSize: 12,
						color: COLORS.sub,
						fontWeight: 500,
						padding: "8px 8px"
					},
					children: "HABIT"
				}), days.map((d, i) => {
					const isToday = todayStr(d) === today;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
						style: {
							fontSize: 12,
							color: COLORS.sub,
							fontWeight: 500,
							padding: "8px 4px",
							background: isToday ? COLORS.blueBg : "transparent",
							borderRadius: 8
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: DAYS[i] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: { fontSize: 11 },
							children: d.getDate()
						})]
					}, i);
				})] }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepWeekRows, {
					store,
					days
				}), habits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					style: {
						padding: "10px 8px",
						borderTop: `1px solid ${COLORS.border}`,
						minWidth: 0
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							fontSize: 13,
							fontWeight: 500,
							overflow: "hidden",
							textOverflow: "ellipsis",
							whiteSpace: "nowrap"
						},
						title: h.name,
						children: h.name
					}), h.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							fontSize: 11,
							color: COLORS.sub,
							overflow: "hidden",
							textOverflow: "ellipsis",
							whiteSpace: "nowrap"
						},
						title: h.description,
						children: h.description
					})]
				}), days.map((d, i) => {
					const ds = todayStr(d);
					const isToday = ds === today;
					const scheduled = h.activeDays.includes(DAYS[i]);
					const checked = !!store.state.logs[ds]?.[h.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						style: {
							textAlign: "center",
							padding: 6,
							borderTop: `1px solid ${COLORS.border}`,
							background: isToday ? COLORS.blueBg : "transparent"
						},
						children: scheduled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => toggle(h.id, ds),
							style: {
								width: 26,
								height: 26,
								borderRadius: 6,
								border: `1px solid ${checked ? COLORS.green : COLORS.border}`,
								background: checked ? COLORS.green : "#fff",
								cursor: "pointer",
								display: "inline-flex",
								alignItems: "center",
								justifyContent: "center"
							},
							children: checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconCheck, { size: 12 })
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
							width: 26,
							height: 26,
							borderRadius: 6,
							background: "#F0F0F3",
							display: "inline-block"
						} })
					}, i);
				})] }, h.id))] })
			]
		})
	})] });
}
function startOfWeek(d) {
	const dt = new Date(d);
	dt.setHours(0, 0, 0, 0);
	const offset = (dt.getDay() + 6) % 7;
	dt.setDate(dt.getDate() - offset);
	return dt;
}
function SleepWeekRows({ store, days }) {
	const today = todayStr();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: [
		{
			label: "Bedtime",
			get: (l) => l?.bedtime || ""
		},
		{
			label: "Wake",
			get: (l) => l?.wake || ""
		},
		{
			label: "Quality",
			get: (l) => l?.quality || ""
		},
		{
			label: "Note",
			get: (l) => l?.note || ""
		}
	].map((row, ri) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
		style: {
			padding: "8px",
			borderTop: `1px solid ${COLORS.border}`,
			background: "#FAFAFB",
			minWidth: 0
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				fontSize: 12,
				fontWeight: 600,
				color: COLORS.sub,
				textTransform: "uppercase",
				letterSpacing: .3
			},
			children: ri === 0 ? "SLEEP" : ri === 3 ? "DAY" : ""
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				fontSize: 13,
				fontWeight: 500
			},
			children: row.label
		})]
	}), days.map((d, i) => {
		const ds = todayStr(d);
		const isToday = ds === today;
		const value = row.get(store.state.sleepLogs[ds]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
			style: {
				textAlign: "center",
				padding: 6,
				borderTop: `1px solid ${COLORS.border}`,
				background: isToday ? COLORS.blueBg : "#FAFAFB"
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				title: value,
				style: {
					fontSize: 12,
					color: value ? COLORS.text : COLORS.sub,
					overflow: "hidden",
					textOverflow: "ellipsis",
					whiteSpace: "nowrap",
					padding: "0 2px"
				},
				children: value || "—"
			})
		}, i);
	})] }, row.label)) });
}
function addDays(d, n) {
	const dt = new Date(d);
	dt.setDate(dt.getDate() + n);
	return dt;
}
function MonthTab({ store }) {
	const [anchor, setAnchor] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		return new Date(d.getFullYear(), d.getMonth(), 1);
	});
	const year = anchor.getFullYear();
	const month = anchor.getMonth();
	const first = new Date(year, month, 1);
	const daysInMonth = new Date(year, month + 1, 0).getDate();
	const startOffset = (first.getDay() + 6) % 7;
	const cells = [];
	for (let i = 0; i < startOffset; i++) cells.push(null);
	for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
	while (cells.length % 7 !== 0) cells.push(null);
	const today = todayStr();
	const habits = store.state.habits;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				justifyContent: "space-between",
				alignItems: "center",
				marginBottom: 16
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setAnchor(new Date(year, month - 1, 1)),
					children: "← Prev"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: { fontWeight: 600 },
					children: anchor.toLocaleDateString("en-US", {
						month: "long",
						year: "numeric"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setAnchor(new Date(year, month + 1, 1)),
					children: "Next →"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "grid",
				gridTemplateColumns: "repeat(7, 1fr)",
				gap: 6
			},
			children: [DAYS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 11,
					color: COLORS.sub,
					fontWeight: 500,
					textAlign: "center",
					padding: 4
				},
				children: d
			}, d)), cells.map((d, i) => {
				if (!d) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, i);
				const ds = todayStr(d);
				const isToday = ds === today;
				const dayName = DAYS[(d.getDay() + 6) % 7];
				const log = store.state.logs[ds] || {};
				const completed = habits.filter((h) => h.activeDays.includes(dayName)).filter((h) => log[h.id]).length;
				const cycleInfo = cycleInfoForDate(store.state.cycle, ds);
				const c = cycleInfo ? PHASE_COLORS[cycleInfo.phase] : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						minHeight: 78,
						border: `1px solid ${COLORS.border}`,
						borderRadius: 10,
						padding: 6,
						background: isToday ? COLORS.blueBg : "#fff",
						position: "relative"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							display: "flex",
							justifyContent: "space-between",
							alignItems: "center"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: 12,
								fontWeight: 500,
								width: 22,
								height: 22,
								display: "flex",
								alignItems: "center",
								justifyContent: "center",
								borderRadius: 999,
								background: isToday ? COLORS.blue : "transparent",
								color: isToday ? "#fff" : COLORS.text
							},
							children: d.getDate()
						}), c && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								width: 16,
								height: 16,
								borderRadius: 999,
								background: c.bg,
								color: c.text,
								fontSize: 10,
								fontWeight: 700,
								display: "flex",
								alignItems: "center",
								justifyContent: "center"
							},
							children: c.letter
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							display: "flex",
							flexWrap: "wrap",
							gap: 2,
							marginTop: 4
						},
						children: Array.from({ length: completed }).map((_, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
							width: 5,
							height: 5,
							borderRadius: 999,
							background: COLORS.green
						} }, j))
					})]
				}, i);
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				gap: 20,
				flexWrap: "wrap",
				marginTop: 16
			},
			children: [[
				"menses",
				"follicular",
				"fertile",
				"luteal"
			].map((p) => {
				const c = PHASE_COLORS[p];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						gap: 6,
						alignItems: "center"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
						width: 12,
						height: 12,
						borderRadius: 999,
						background: c.bg
					} }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
						style: { fontSize: 12 },
						children: c.label
					})]
				}, p);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 6,
					alignItems: "center"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
					width: 6,
					height: 6,
					borderRadius: 999,
					background: COLORS.green
				} }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
					style: { fontSize: 12 },
					children: "Habit completed"
				})]
			})]
		})
	] });
}
function CycleTab({ store }) {
	const [date, setDate] = (0, import_react.useState)(todayStr());
	const c = store.state.cycle;
	const info = cycleInfoForDate(c, todayStr());
	const logPeriod = () => {
		if (!date) return;
		store.update((s) => {
			if (s.cycle.periods.find((p) => p.start === date)) return s;
			return {
				...s,
				cycle: {
					...s.cycle,
					periods: [...s.cycle.periods, {
						start: date,
						logged: true
					}]
				}
			};
		});
	};
	const remove = (start) => {
		store.update((s) => ({
			...s,
			cycle: {
				...s.cycle,
				periods: s.cycle.periods.filter((p) => p.start !== start)
			}
		}));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Current Cycle" }), info ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 12
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						fontSize: 22,
						fontWeight: 700
					},
					children: ["Day ", info.day]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhasePill, {
					phase: info.phase,
					estimated: info.estimated
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Log your first period to begin tracking." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Log Period Start" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						gap: 8,
						flexWrap: "wrap"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value),
						style: { width: 200 }
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: logPeriod,
						children: "Log"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						marginTop: 16,
						display: "grid",
						gap: 6
					},
					children: [[...c.periods].sort((a, b) => b.start.localeCompare(a.start)).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							display: "flex",
							justifyContent: "space-between",
							padding: "6px 0",
							borderBottom: `1px solid ${COLORS.border}`
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: { fontSize: 14 },
							children: p.start
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => remove(p.start),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
						})]
					}, p.start)), c.periods.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No periods logged." })]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Averages" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gridTemplateColumns: "1fr 1fr",
					gap: 12
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					style: {
						display: "grid",
						gap: 6,
						fontSize: 13
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Cycle length (days)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: c.avgCycleLength,
						onChange: (e) => store.update((s) => ({
							...s,
							cycle: {
								...s.cycle,
								avgCycleLength: Number(e.target.value) || 28
							}
						}))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					style: {
						display: "grid",
						gap: 6,
						fontSize: 13
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Period length (days)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: c.avgPeriodLength,
						onChange: (e) => store.update((s) => ({
							...s,
							cycle: {
								...s.cycle,
								avgPeriodLength: Number(e.target.value) || 5
							}
						}))
					})]
				})]
			})] })
		]
	});
}
function TodosTab({ store }) {
	const [text, setText] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [editText, setEditText] = (0, import_react.useState)("");
	const add = () => {
		if (!text.trim()) return;
		store.update((s) => ({
			...s,
			todos: [...s.todos, {
				id: uid(),
				text: text.trim(),
				done: false,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				completedAt: null
			}]
		}));
		setText("");
	};
	const toggle = (id) => store.update((s) => ({
		...s,
		todos: s.todos.map((t) => t.id === id ? {
			...t,
			done: !t.done,
			completedAt: !t.done ? (/* @__PURE__ */ new Date()).toISOString() : null
		} : t)
	}));
	const del = (id) => store.update((s) => ({
		...s,
		todos: s.todos.filter((t) => t.id !== id)
	}));
	const clearCompleted = () => store.update((s) => ({
		...s,
		todos: s.todos.filter((t) => !t.done)
	}));
	const saveEdit = (id) => {
		store.update((s) => ({
			...s,
			todos: s.todos.map((t) => t.id === id ? {
				...t,
				text: editText
			} : t)
		}));
		setEditingId(null);
	};
	const active = store.state.todos.filter((t) => !t.done);
	const completed = store.state.todos.filter((t) => t.done).sort((a, b) => (b.completedAt || "").localeCompare(a.completedAt || ""));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "To-Dos" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					marginBottom: 12
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: "Add a task...",
					onKeyDown: (e) => e.key === "Enter" && add()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: add,
					children: "Add"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gap: 6
				},
				children: [active.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 10,
						padding: "6px 0",
						borderBottom: `1px solid ${COLORS.border}`
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: t.done,
						onClick: () => toggle(t.id)
					}), editingId === t.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editText,
							onChange: (e) => setEditText(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => saveEdit(t.id),
							children: "Save"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => setEditingId(null),
							children: "Cancel"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								flex: 1,
								fontSize: 14
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: t.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
								style: { fontSize: 11 },
								children: ["Added ", formatTs(t.createdAt)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => {
								setEditingId(t.id);
								setEditText(t.text);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconPencil, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => del(t.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
						})
					] })]
				}, t.id)), active.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No active tasks." })]
			})
		] }), completed.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				justifyContent: "space-between",
				alignItems: "center",
				marginBottom: 12
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, { children: [
				"Completed (",
				completed.length,
				")"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: clearCompleted,
				children: "Clear all"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				display: "grid",
				gap: 6
			},
			children: completed.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 10,
					padding: "6px 0",
					borderBottom: `1px solid ${COLORS.border}`
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: true,
						onClick: () => toggle(t.id)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							flex: 1,
							fontSize: 14,
							color: COLORS.sub,
							textDecoration: "line-through"
						},
						children: t.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
						style: { fontSize: 12 },
						children: formatTs(t.completedAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => del(t.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
					})
				]
			}, t.id))
		})] })]
	});
}
function Checkbox({ checked, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick,
		style: {
			width: 22,
			height: 22,
			borderRadius: 6,
			border: `1.5px solid ${checked ? COLORS.green : COLORS.border}`,
			background: checked ? COLORS.green : "#fff",
			cursor: "pointer",
			display: "inline-flex",
			alignItems: "center",
			justifyContent: "center"
		},
		children: checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconCheck, { size: 12 })
	});
}
function BuysTab({ store }) {
	const [text, setText] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [editText, setEditText] = (0, import_react.useState)("");
	const [editPrice, setEditPrice] = (0, import_react.useState)("");
	const add = () => {
		if (!text.trim()) return;
		store.update((s) => ({
			...s,
			buys: [...s.buys, {
				id: uid(),
				text: text.trim(),
				price: Number(price) || 0,
				done: false,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				completedAt: null
			}]
		}));
		setText("");
		setPrice("");
	};
	const toggle = (id) => store.update((s) => ({
		...s,
		buys: s.buys.map((b) => b.id === id ? {
			...b,
			done: !b.done,
			completedAt: !b.done ? (/* @__PURE__ */ new Date()).toISOString() : null
		} : b)
	}));
	const del = (id) => store.update((s) => ({
		...s,
		buys: s.buys.filter((b) => b.id !== id)
	}));
	const clearCompleted = () => store.update((s) => ({
		...s,
		buys: s.buys.filter((b) => !b.done)
	}));
	const saveEdit = (id) => {
		store.update((s) => ({
			...s,
			buys: s.buys.map((b) => b.id === id ? {
				...b,
				text: editText,
				price: Number(editPrice) || 0
			} : b)
		}));
		setEditingId(null);
	};
	const active = store.state.buys.filter((b) => !b.done);
	const completed = store.state.buys.filter((b) => b.done).sort((a, b) => (b.completedAt || "").localeCompare(a.completedAt || ""));
	const totalActive = active.reduce((s, b) => s + b.price, 0);
	const totalAll = store.state.buys.reduce((s, b) => s + b.price, 0);
	const fmt = (n) => n.toLocaleString(void 0, {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					alignItems: "baseline",
					marginBottom: 12,
					flexWrap: "wrap",
					gap: 8
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "To-Buys" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						gap: 16,
						fontSize: 13
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Pending: " }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmt(totalActive) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "All: " }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmt(totalAll) })] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					marginBottom: 12,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: text,
						onChange: (e) => setText(e.target.value),
						placeholder: "Item...",
						style: {
							flex: 2,
							minWidth: 160
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: price,
						onChange: (e) => setPrice(e.target.value),
						placeholder: "Price",
						style: {
							flex: 1,
							minWidth: 100
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: add,
						children: "Add"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gap: 6
				},
				children: [active.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 10,
						padding: "6px 0",
						borderBottom: `1px solid ${COLORS.border}`
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: b.done,
						onClick: () => toggle(b.id)
					}), editingId === b.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editText,
							onChange: (e) => setEditText(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: editPrice,
							onChange: (e) => setEditPrice(e.target.value),
							style: { maxWidth: 100 }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => saveEdit(b.id),
							children: "Save"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => setEditingId(null),
							children: "Cancel"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								flex: 1,
								fontSize: 14
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: b.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
								style: { fontSize: 11 },
								children: ["Added ", formatTs(b.createdAt)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: { fontSize: 14 },
							children: fmt(b.price)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => {
								setEditingId(b.id);
								setEditText(b.text);
								setEditPrice(String(b.price));
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconPencil, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => del(b.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
						})
					] })]
				}, b.id)), active.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No pending items." })]
			})
		] }), completed.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				justifyContent: "space-between",
				alignItems: "center",
				marginBottom: 12
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, { children: [
				"Completed (",
				completed.length,
				")"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: clearCompleted,
				children: "Clear all"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				display: "grid",
				gap: 6
			},
			children: completed.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 10,
					padding: "6px 0",
					borderBottom: `1px solid ${COLORS.border}`
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: true,
						onClick: () => toggle(b.id)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							flex: 1,
							fontSize: 14,
							color: COLORS.sub,
							textDecoration: "line-through"
						},
						children: b.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							fontSize: 14,
							color: COLORS.sub
						},
						children: fmt(b.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
						style: { fontSize: 12 },
						children: formatTs(b.completedAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => del(b.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
					})
				]
			}, b.id))
		})] })]
	});
}
function GroceryTab({ store }) {
	const [text, setText] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [editText, setEditText] = (0, import_react.useState)("");
	const [editPrice, setEditPrice] = (0, import_react.useState)("");
	const add = () => {
		if (!text.trim()) return;
		store.update((s) => ({
			...s,
			groceries: [...s.groceries, {
				id: uid(),
				text: text.trim(),
				price: Number(price) || 0,
				done: false,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				completedAt: null
			}]
		}));
		setText("");
		setPrice("");
	};
	const toggle = (id) => store.update((s) => ({
		...s,
		groceries: s.groceries.map((g) => g.id === id ? {
			...g,
			done: !g.done,
			completedAt: !g.done ? (/* @__PURE__ */ new Date()).toISOString() : null
		} : g)
	}));
	const del = (id) => store.update((s) => ({
		...s,
		groceries: s.groceries.filter((g) => g.id !== id)
	}));
	const clearCompleted = () => store.update((s) => ({
		...s,
		groceries: s.groceries.filter((g) => !g.done)
	}));
	const saveEdit = (id) => {
		store.update((s) => ({
			...s,
			groceries: s.groceries.map((g) => g.id === id ? {
				...g,
				text: editText,
				price: Number(editPrice) || 0
			} : g)
		}));
		setEditingId(null);
	};
	const active = store.state.groceries.filter((g) => !g.done);
	const completed = store.state.groceries.filter((g) => g.done).sort((a, b) => (b.completedAt || "").localeCompare(a.completedAt || ""));
	const totalActive = active.reduce((s, g) => s + (Number(g.price) || 0), 0);
	const totalAll = store.state.groceries.reduce((s, g) => s + (Number(g.price) || 0), 0);
	const fmt = (n) => "$" + (n || 0).toLocaleString(void 0, {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					alignItems: "baseline",
					marginBottom: 12,
					flexWrap: "wrap",
					gap: 8
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Grocery" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						gap: 16,
						fontSize: 13
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Pending: " }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmt(totalActive) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "All: " }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmt(totalAll) })] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
				style: { fontSize: 12 },
				children: "Household items to pick up."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					marginTop: 12,
					marginBottom: 12,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: text,
						onChange: (e) => setText(e.target.value),
						placeholder: "Item...",
						style: {
							flex: 2,
							minWidth: 160
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: price,
						onChange: (e) => setPrice(e.target.value),
						placeholder: "Price",
						style: {
							flex: 1,
							minWidth: 100
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: add,
						children: "Add"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gap: 6
				},
				children: [active.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 10,
						padding: "6px 0",
						borderBottom: `1px solid ${COLORS.border}`
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: g.done,
						onClick: () => toggle(g.id)
					}), editingId === g.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editText,
							onChange: (e) => setEditText(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: editPrice,
							onChange: (e) => setEditPrice(e.target.value),
							style: { maxWidth: 100 }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => saveEdit(g.id),
							children: "Save"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => setEditingId(null),
							children: "Cancel"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								flex: 1,
								fontSize: 14
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: g.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
								style: { fontSize: 11 },
								children: ["Added ", formatTs(g.createdAt)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: { fontSize: 14 },
							children: fmt(Number(g.price) || 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => {
								setEditingId(g.id);
								setEditText(g.text);
								setEditPrice(String(g.price || 0));
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconPencil, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => del(g.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
						})
					] })]
				}, g.id)), active.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No items on the list." })]
			})
		] }), completed.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				justifyContent: "space-between",
				alignItems: "center",
				marginBottom: 12
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, { children: [
				"Completed (",
				completed.length,
				")"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: clearCompleted,
				children: "Clear all"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				display: "grid",
				gap: 6
			},
			children: completed.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 10,
					padding: "6px 0",
					borderBottom: `1px solid ${COLORS.border}`
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: true,
						onClick: () => toggle(g.id)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							flex: 1,
							fontSize: 14,
							color: COLORS.sub,
							textDecoration: "line-through"
						},
						children: g.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							fontSize: 14,
							color: COLORS.sub
						},
						children: fmt(Number(g.price) || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
						style: { fontSize: 12 },
						children: formatTs(g.completedAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => del(g.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
					})
				]
			}, g.id))
		})] })]
	});
}
function AnalysisTab({ store }) {
	const [range, setRange] = (0, import_react.useState)("month");
	const [anchor, setAnchor] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const { start, end, label } = getRange(anchor, range);
	const dates = enumerateDates(start, end);
	const habits = [...store.state.habits].sort((a, b) => a.order - b.order);
	const habitStats = habits.map((h) => {
		const scheduledDates = dates.filter((d) => h.activeDays.includes(DAYS[(d.getDay() + 6) % 7]));
		const completed = scheduledDates.filter((d) => !!store.state.logs[todayStr(d)]?.[h.id]);
		let cur = 0, longest = 0, run = 0;
		scheduledDates.forEach((d) => {
			if (store.state.logs[todayStr(d)]?.[h.id]) {
				run++;
				longest = Math.max(longest, run);
			} else run = 0;
		});
		const todayIdx = scheduledDates.length - 1;
		for (let i = todayIdx; i >= 0; i--) if (store.state.logs[todayStr(scheduledDates[i])]?.[h.id]) cur++;
		else break;
		return {
			habit: h,
			pct: scheduledDates.length ? Math.round(completed.length / scheduledDates.length * 100) : 0,
			current: cur,
			longest
		};
	});
	const trend = bucketize(start, end, range).map((b) => {
		const bDates = enumerateDates(b.start, b.end);
		let total = 0, done = 0;
		for (const d of bDates) {
			const dayName = DAYS[(d.getDay() + 6) % 7];
			const sch = habits.filter((h) => h.activeDays.includes(dayName));
			total += sch.length;
			const log = store.state.logs[todayStr(d)] || {};
			for (const h of sch) if (log[h.id]) done++;
		}
		return {
			label: b.label,
			pct: total ? Math.round(done / total * 100) : 0
		};
	});
	const cyclePhases = {
		menses: {
			total: 0,
			done: 0
		},
		follicular: {
			total: 0,
			done: 0
		},
		fertile: {
			total: 0,
			done: 0
		},
		luteal: {
			total: 0,
			done: 0
		}
	};
	for (const d of dates) {
		const ds = todayStr(d);
		const info = cycleInfoForDate(store.state.cycle, ds);
		if (!info) continue;
		const dayName = DAYS[(d.getDay() + 6) % 7];
		const sch = habits.filter((h) => h.activeDays.includes(dayName));
		const log = store.state.logs[ds] || {};
		cyclePhases[info.phase].total += sch.length;
		for (const h of sch) if (log[h.id]) cyclePhases[info.phase].done++;
	}
	const todosInRange = store.state.todos.filter((t) => t.createdAt >= todayStr(start) && t.createdAt <= todayStr(end));
	const todosCompleted = store.state.todos.filter((t) => t.completedAt && t.completedAt >= todayStr(start) && t.completedAt <= todayStr(end));
	const avgDays = todosCompleted.length ? Math.round(todosCompleted.reduce((s, t) => s + (t.completedAt ? Math.max(0, (new Date(t.completedAt).getTime() - new Date(t.createdAt).getTime()) / 864e5) : 0), 0) / todosCompleted.length * 10) / 10 : 0;
	const buysInRange = store.state.buys.filter((b) => b.done && b.completedAt && b.completedAt >= todayStr(start) && b.completedAt <= todayStr(end));
	const totalSpend = buysInRange.reduce((s, b) => s + b.price, 0);
	const fmt = (n) => "$" + n.toLocaleString(void 0, {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
	const exportCsv = () => {
		const rows = ["type,date,item,value,extra"];
		for (const d of dates) {
			const ds = todayStr(d);
			const log = store.state.logs[ds] || {};
			for (const h of habits) if (log[h.id]) rows.push(`habit,${ds},"${escapeCsv(h.name)}",1,`);
		}
		for (const t of todosInRange) rows.push(`todo,${t.createdAt},"${escapeCsv(t.text)}",${t.done ? 1 : 0},${t.completedAt || ""}`);
		for (const b of store.state.buys.filter((x) => x.createdAt >= todayStr(start) && x.createdAt <= todayStr(end))) rows.push(`buy,${b.createdAt},"${escapeCsv(b.text)}",${b.price},${b.completedAt || ""}`);
		const csv = rows.join("\n");
		const blob = new Blob([csv], { type: "text/csv" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `habit-tracker-${label.replace(/\s+/g, "-")}.csv`;
		a.click();
		URL.revokeObjectURL(url);
	};
	const stepAnchor = (dir) => {
		const d = new Date(anchor);
		if (range === "month") d.setMonth(d.getMonth() + dir);
		else if (range === "quarter") d.setMonth(d.getMonth() + dir * 3);
		else d.setFullYear(d.getFullYear() + dir);
		setAnchor(d);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					alignItems: "center",
					gap: 12,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							display: "flex",
							background: "#EDEDF0",
							borderRadius: 999,
							padding: 4
						},
						children: [
							"month",
							"quarter",
							"year"
						].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setRange(r),
							style: {
								border: "none",
								cursor: "pointer",
								background: range === r ? COLORS.text : "transparent",
								color: range === r ? "#fff" : COLORS.sub,
								padding: "6px 14px",
								borderRadius: 999,
								fontSize: 13,
								fontWeight: 500,
								textTransform: "capitalize"
							},
							children: [r, "ly"]
						}, r))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							display: "flex",
							gap: 8,
							alignItems: "center"
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => stepAnchor(-1),
								children: "←"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: {
									fontWeight: 600,
									minWidth: 140,
									textAlign: "center"
								},
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => stepAnchor(1),
								children: "→"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: exportCsv,
						children: "Export CSV"
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Habit Consistency" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gap: 8
				},
				children: [habitStats.map(({ habit, pct, current, longest }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "grid",
						gridTemplateColumns: "1fr auto",
						gap: 6,
						alignItems: "center"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { minWidth: 0 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: 13,
								fontWeight: 500,
								overflow: "hidden",
								textOverflow: "ellipsis",
								whiteSpace: "nowrap"
							},
							title: habit.name,
							children: habit.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								height: 6,
								background: "#EDEDF0",
								borderRadius: 999,
								marginTop: 4,
								overflow: "hidden"
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
								width: `${pct}%`,
								height: "100%",
								background: COLORS.green
							} })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							fontSize: 12,
							textAlign: "right",
							minWidth: 120
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [pct, "%"] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, {
							style: { fontSize: 11 },
							children: [
								"streak ",
								current,
								" · best ",
								longest
							]
						})]
					})]
				}, habit.id)), habitStats.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No habits." })]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Overall Trend" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "flex",
					alignItems: "flex-end",
					gap: 6,
					height: 140
				},
				children: trend.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						flex: 1,
						display: "flex",
						flexDirection: "column",
						alignItems: "center",
						gap: 4
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							width: "100%",
							background: COLORS.blue,
							borderRadius: 4,
							height: `${t.pct}%`,
							minHeight: 2,
							opacity: .85
						},
						title: `${t.pct}%`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
						style: { fontSize: 10 },
						children: t.label
					})]
				}, i))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Cycle Correlation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "grid",
					gridTemplateColumns: "repeat(2, 1fr)",
					gap: 12
				},
				children: [
					"menses",
					"follicular",
					"fertile",
					"luteal"
				].map((p) => {
					const c = PHASE_COLORS[p];
					const pct = cyclePhases[p].total ? Math.round(cyclePhases[p].done / cyclePhases[p].total * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							background: c.bg,
							borderRadius: 10,
							padding: 12
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: 12,
								color: c.text,
								fontWeight: 600
							},
							children: c.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontSize: 22,
								fontWeight: 700,
								color: c.text
							},
							children: [pct, "%"]
						})]
					}, p);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "To-Do Throughput" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 24,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Created",
						value: todosInRange.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Completed",
						value: todosCompleted.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Avg days to complete",
						value: avgDays
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "To-Buy Spend" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: `Total spent in ${label}`,
					value: fmt(totalSpend)
				}),
				range !== "month" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						marginTop: 12,
						display: "grid",
						gap: 4
					},
					children: monthlyBreakdown(buysInRange).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							display: "flex",
							justifyContent: "space-between",
							fontSize: 13
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: m.month }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmt(m.total) })]
					}, m.month))
				})
			] })
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
		style: { fontSize: 12 },
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			fontSize: 22,
			fontWeight: 700
		},
		children: value
	})] });
}
function monthlyBreakdown(buys) {
	const map = {};
	for (const b of buys) {
		if (!b.completedAt) continue;
		const m = b.completedAt.slice(0, 7);
		map[m] = (map[m] || 0) + b.price;
	}
	return Object.keys(map).sort().map((month) => ({
		month,
		total: map[month]
	}));
}
function escapeCsv(s) {
	return s.replace(/"/g, "\"\"");
}
function enumerateDates(start, end) {
	const out = [];
	const d = new Date(start);
	while (d <= end) {
		out.push(new Date(d));
		d.setDate(d.getDate() + 1);
	}
	return out;
}
function getRange(anchor, range) {
	const y = anchor.getFullYear();
	if (range === "month") return {
		start: new Date(y, anchor.getMonth(), 1),
		end: new Date(y, anchor.getMonth() + 1, 0),
		label: anchor.toLocaleDateString("en-US", {
			month: "long",
			year: "numeric"
		})
	};
	if (range === "quarter") {
		const q = Math.floor(anchor.getMonth() / 3);
		return {
			start: new Date(y, q * 3, 1),
			end: new Date(y, q * 3 + 3, 0),
			label: `Q${q + 1} ${y}`
		};
	}
	return {
		start: new Date(y, 0, 1),
		end: new Date(y, 11, 31),
		label: String(y)
	};
}
function bucketize(start, end, range) {
	if (range === "month") {
		const out = [];
		let cur = new Date(start);
		let idx = 1;
		while (cur <= end) {
			const bStart = new Date(cur);
			const bEnd = new Date(cur);
			bEnd.setDate(bEnd.getDate() + 6);
			if (bEnd > end) bEnd.setTime(end.getTime());
			out.push({
				start: bStart,
				end: bEnd,
				label: `W${idx}`
			});
			cur = new Date(bEnd);
			cur.setDate(cur.getDate() + 1);
			idx++;
		}
		return out;
	}
	if (range === "quarter") {
		const out = [];
		let m = new Date(start);
		while (m <= end) {
			const bStart = new Date(m.getFullYear(), m.getMonth(), 1);
			const bEnd = new Date(m.getFullYear(), m.getMonth() + 1, 0);
			out.push({
				start: bStart,
				end: bEnd,
				label: m.toLocaleDateString("en-US", { month: "short" })
			});
			m = new Date(m.getFullYear(), m.getMonth() + 1, 1);
		}
		return out;
	}
	const out = [];
	for (let mo = 0; mo < 12; mo++) {
		const bStart = new Date(start.getFullYear(), mo, 1);
		const bEnd = new Date(start.getFullYear(), mo + 1, 0);
		out.push({
			start: bStart,
			end: bEnd,
			label: bStart.toLocaleDateString("en-US", { month: "short" })[0]
		});
	}
	return out;
}
function HabitsTab({ store }) {
	const [name, setName] = (0, import_react.useState)("");
	const [desc, setDesc] = (0, import_react.useState)("");
	const [days, setDays] = (0, import_react.useState)(ALL_DAYS);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [editName, setEditName] = (0, import_react.useState)("");
	const [editDesc, setEditDesc] = (0, import_react.useState)("");
	const [editDays, setEditDays] = (0, import_react.useState)([]);
	const habits = [...store.state.habits].sort((a, b) => a.order - b.order);
	const add = () => {
		if (!name.trim()) return;
		const maxOrder = habits.reduce((m, h) => Math.max(m, h.order), -1);
		store.update((s) => ({
			...s,
			habits: [...s.habits, {
				id: uid(),
				name: name.trim(),
				description: desc.trim(),
				order: maxOrder + 1,
				activeDays: days.length ? days : ALL_DAYS
			}]
		}));
		setName("");
		setDesc("");
		setDays(ALL_DAYS);
	};
	const del = (id) => store.update((s) => ({
		...s,
		habits: s.habits.filter((h) => h.id !== id)
	}));
	const move = (id, dir) => {
		store.update((s) => {
			const sorted = [...s.habits].sort((a, b) => a.order - b.order);
			const idx = sorted.findIndex((h) => h.id === id);
			const other = idx + dir;
			if (other < 0 || other >= sorted.length) return s;
			const a = sorted[idx], b = sorted[other];
			const swap = a.order;
			a.order = b.order;
			b.order = swap;
			return {
				...s,
				habits: s.habits.map((h) => h.id === a.id ? a : h.id === b.id ? b : h)
			};
		});
	};
	const startEdit = (h) => {
		setEditingId(h.id);
		setEditName(h.name);
		setEditDesc(h.description);
		setEditDays(h.activeDays);
	};
	const saveEdit = () => {
		store.update((s) => ({
			...s,
			habits: s.habits.map((h) => h.id === editingId ? {
				...h,
				name: editName,
				description: editDesc,
				activeDays: editDays.length ? editDays : ALL_DAYS
			} : h)
		}));
		setEditingId(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Add Habit" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "grid",
				gap: 10
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Name",
					value: name,
					onChange: (e) => setName(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Description (optional)",
					value: desc,
					onChange: (e) => setDesc(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DaysSelector, {
					value: days,
					onChange: setDays
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: add,
					children: "Add habit"
				}) })
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, { children: [
			"All Habits (",
			habits.length,
			")"
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				display: "grid",
				gap: 8
			},
			children: habits.map((h, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					padding: "10px 0",
					borderBottom: `1px solid ${COLORS.border}`
				},
				children: editingId === h.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "grid",
						gap: 8
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editName,
							onChange: (e) => setEditName(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editDesc,
							onChange: (e) => setEditDesc(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DaysSelector, {
							value: editDays,
							onChange: setEditDays
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								gap: 8
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: saveEdit,
								children: "Save"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => setEditingId(null),
								children: "Cancel"
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "flex-start",
						gap: 10
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								flexDirection: "column",
								gap: 2
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => move(h.id, -1),
								disabled: idx === 0,
								style: {
									border: `1px solid ${COLORS.border}`,
									background: "#fff",
									borderRadius: 6,
									padding: 2,
									cursor: idx === 0 ? "not-allowed" : "pointer",
									opacity: idx === 0 ? .4 : 1
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArrowUp, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => move(h.id, 1),
								disabled: idx === habits.length - 1,
								style: {
									border: `1px solid ${COLORS.border}`,
									background: "#fff",
									borderRadius: 6,
									padding: 2,
									cursor: idx === habits.length - 1 ? "not-allowed" : "pointer",
									opacity: idx === habits.length - 1 ? .4 : 1
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArrowDown, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								flex: 1,
								minWidth: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									style: {
										fontSize: 14,
										fontWeight: 500
									},
									children: h.name
								}),
								h.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
									style: { fontSize: 12 },
									children: h.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									style: {
										fontSize: 11,
										color: COLORS.sub,
										marginTop: 4
									},
									children: h.activeDays.join(" · ")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => startEdit(h),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconPencil, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => del(h.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
						})
					]
				})
			}, h.id))
		})] })]
	});
}
function RemindersTab({ store }) {
	const [habitId, setHabitId] = (0, import_react.useState)("");
	const [time, setTime] = (0, import_react.useState)("09:00");
	const [perm, setPerm] = (0, import_react.useState)(typeof Notification === "undefined" ? "unsupported" : Notification.permission);
	const habits = [...store.state.habits].sort((a, b) => a.order - b.order);
	const habitName = (id) => habits.find((h) => h.id === id)?.name || "(deleted)";
	const add = () => {
		if (!habitId) return;
		store.update((s) => ({
			...s,
			reminders: [...s.reminders, {
				id: uid(),
				habitId,
				time
			}]
		}));
	};
	const del = (id) => store.update((s) => ({
		...s,
		reminders: s.reminders.filter((r) => r.id !== id)
	}));
	const request = async () => {
		if (typeof Notification === "undefined") return;
		const p = await Notification.requestPermission();
		setPerm(p);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 16
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Notifications" }), perm === "unsupported" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Not supported in this browser." }) : perm === "granted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Notifications enabled." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 10,
					alignItems: "center"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Muted, { children: ["Status: ", perm] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: request,
					children: "Enable notifications"
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Add Reminder" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					flexWrap: "wrap",
					alignItems: "center"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: habitId,
						onChange: (e) => setHabitId(e.target.value),
						style: {
							border: `1px solid ${COLORS.border}`,
							borderRadius: 10,
							padding: "8px 12px",
							background: "#fff",
							fontSize: 14,
							flex: 1,
							minWidth: 200
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Select habit"
						}), habits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: h.id,
							children: h.name
						}, h.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "time",
						value: time,
						onChange: (e) => setTime(e.target.value),
						style: { width: 130 }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: add,
						children: "Add"
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Reminders" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gap: 6
				},
				children: [store.state.reminders.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 10,
						padding: "6px 0",
						borderBottom: `1px solid ${COLORS.border}`
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								flex: 1,
								fontSize: 14
							},
							children: habitName(r.habitId)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: 14,
								fontWeight: 500
							},
							children: r.time
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => del(r.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrash, {})
						})
					]
				}, r.id)), store.state.reminders.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "No reminders yet." })]
			})] })
		]
	});
}
function useReminderNotifier(store) {
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined" || typeof Notification === "undefined") return;
		const firedKey = "habit-tracker-fired-reminders";
		const getFired = () => {
			try {
				return JSON.parse(window.localStorage.getItem(firedKey) || "{}");
			} catch {
				return {};
			}
		};
		const setFired = (v) => window.localStorage.setItem(firedKey, JSON.stringify(v));
		const check = () => {
			if (Notification.permission !== "granted") return;
			const now = /* @__PURE__ */ new Date();
			const cur = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
			const today = todayStr(now);
			const dayName = DAYS[(now.getDay() + 6) % 7];
			const fired = getFired();
			const cleaned = {};
			for (const k of Object.keys(fired)) if (k.startsWith(today)) cleaned[k] = fired[k];
			for (const r of store.state.reminders) {
				if (r.time !== cur) continue;
				const habit = store.state.habits.find((h) => h.id === r.habitId);
				if (!habit) continue;
				if (!habit.activeDays.includes(dayName)) continue;
				if (store.state.logs[today]?.[habit.id]) continue;
				const key = `${today}|${r.id}`;
				if (cleaned[key]) continue;
				try {
					new Notification("Habit Tracker", { body: `Reminder: ${habit.name}` });
				} catch {}
				cleaned[key] = true;
			}
			setFired(cleaned);
		};
		const interval = window.setInterval(check, 2e4);
		check();
		return () => window.clearInterval(interval);
	}, [
		store.state.reminders,
		store.state.habits,
		store.state.logs
	]);
}
function IndexPage() {
	const { isPending, userId } = useAuth();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!isPending && !userId) navigate({ to: "/login" });
	}, [
		isPending,
		userId,
		navigate
	]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			minHeight: "100vh",
			display: "flex",
			alignItems: "center",
			justifyContent: "center",
			background: COLORS.bg
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			style: {
				color: COLORS.sub,
				fontSize: 14
			},
			children: "Loading..."
		})
	});
	if (!userId) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitApp, {});
}
//#endregion
export { IndexPage as component };
