import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-BmBluzMB.js
var import_jsx_runtime = require_jsx_runtime();
var COLORS = {
	bg: "#F5F5F7",
	card: "#FFFFFF",
	border: "#E5E5EA",
	text: "#1D1D1F",
	sub: "#6E6E73",
	blue: "#0071E3",
	blueBg: "#E5F1FC",
	green: "#34C759"
};
function Card({ children, style, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className,
		style: {
			background: COLORS.card,
			border: `1px solid ${COLORS.border}`,
			borderRadius: 12,
			padding: 20,
			...style
		},
		children
	});
}
function Button({ children, onClick, variant = "primary", type = "button", disabled, style, title }) {
	const base = {
		borderRadius: 10,
		padding: "8px 14px",
		fontSize: 14,
		fontWeight: 500,
		border: "1px solid transparent",
		cursor: disabled ? "not-allowed" : "pointer",
		opacity: disabled ? .5 : 1,
		transition: "background 120ms ease"
	};
	const variants = {
		primary: {
			background: COLORS.blue,
			color: "#fff"
		},
		secondary: {
			background: "#fff",
			color: COLORS.text,
			borderColor: COLORS.border
		},
		ghost: {
			background: "transparent",
			color: COLORS.sub
		},
		danger: {
			background: "#fff",
			color: "#C53030",
			borderColor: COLORS.border
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		disabled,
		title,
		style: {
			...base,
			...variants[variant],
			...style
		},
		children
	});
}
function Input(props) {
	const { style, ...rest } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...rest,
		style: {
			border: `1px solid ${COLORS.border}`,
			borderRadius: 10,
			padding: "8px 12px",
			fontSize: 14,
			background: "#fff",
			color: COLORS.text,
			outline: "none",
			width: "100%",
			...style
		}
	});
}
function Textarea(props) {
	const { style, ...rest } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...rest,
		style: {
			border: `1px solid ${COLORS.border}`,
			borderRadius: 10,
			padding: "8px 12px",
			fontSize: 14,
			background: "#fff",
			color: COLORS.text,
			outline: "none",
			width: "100%",
			resize: "vertical",
			minHeight: 60,
			fontFamily: "inherit",
			...style
		}
	});
}
function SectionTitle({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		style: {
			fontSize: 18,
			fontWeight: 600,
			color: COLORS.text,
			margin: "0 0 12px"
		},
		children
	});
}
function Muted({ children, style }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		style: {
			color: COLORS.sub,
			...style
		},
		children
	});
}
function IconPencil() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "14",
		height: "14",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 20h9" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16.5 3.5a2.121 2.121 0 1 1 3 3L7 19l-4 1 1-4L16.5 3.5z" })]
	});
}
function IconCheck({ size = 14 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "#fff",
		strokeWidth: "3",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "20 6 9 17 4 12" })
	});
}
function IconTrash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "14",
		height: "14",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "3 6 5 6 21 6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 11v6M14 11v6" })
		]
	});
}
function IconArrowUp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "14",
		height: "14",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "18 15 12 9 6 15" })
	});
}
function IconArchive() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "14",
		height: "14",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "2",
				y: "3",
				width: "20",
				height: "5",
				rx: "1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 12h4" })
		]
	});
}
function IconArrowDown() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "14",
		height: "14",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "6 9 12 15 18 9" })
	});
}
//#endregion
export { IconArrowDown as a, IconPencil as c, Muted as d, SectionTitle as f, IconArchive as i, IconTrash as l, COLORS as n, IconArrowUp as o, Textarea as p, Card as r, IconCheck as s, Button as t, Input as u };
